import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DocumentParserFormComponent } from './Parser/Components/document-parser-form/document-parser-form.component';

const routes: Routes = [
  { path: '', component: DocumentParserFormComponent},
  { path: '', redirectTo: '/opportunity', pathMatch: 'full' },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

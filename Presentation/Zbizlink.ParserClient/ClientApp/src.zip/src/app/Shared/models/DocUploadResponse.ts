import { SummaryField } from './SummaryField';

export class DocUploadResponse {
    CategoryData: Array<string>;
    status: string;
    category: Array<string>;
    document: string;
    filePath: string;
    summary: Array<SummaryField>;
    documentId: string;
    documentName: string;

    
}

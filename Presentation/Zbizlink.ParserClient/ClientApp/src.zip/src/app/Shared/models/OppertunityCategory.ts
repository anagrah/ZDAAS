
 export class OppertunityCategory {
   id: number;
   categoryId: string=null //  ==> CategoryName
   categoryName:string=null
   categoryData: Element[]=[];
 }
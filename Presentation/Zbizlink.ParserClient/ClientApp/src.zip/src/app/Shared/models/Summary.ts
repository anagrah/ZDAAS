export class Summary {
  summaryId: number;
  proposalName: string;
  solicitationNumber: string;
  startDate: string;
  dueDateTime: string;
  preBidDate: string;
  QADate: string;
  }



export class SharePointDocUploadResponse 
{
    Status:string;
    Message:string;
    FilePath:string;
}
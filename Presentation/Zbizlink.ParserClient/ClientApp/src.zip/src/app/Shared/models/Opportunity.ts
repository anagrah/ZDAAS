export class Opportunity {
  constructor(
    // scope: string, Background: string, TechnicalRequirement: string, OtherRequirement: string, Capability: string, Position: string, LaborCategory: string
  ) {

    this.scope = "";
    this.Background = "";
    this.TechnicalRequirement = "";
    this.OtherRequirement = "";
    this.Capability = "";
    this.Position = "";
    this.LaborCategory = "";
  }
  scope: string;
  Background: string;
  TechnicalRequirement: string;
  OtherRequirement: string;
  Capability: string;
  Position: string;
  LaborCategory: string;
  // isEqual function is not in use now: I have created another function serverice for this purpsoe 
  isEqual(param1: Opportunity, param2: Opportunity): Boolean {
    let status;
    if (param1.Background.toString() != param2.Background.toString()) {
      status = false;;
    } else if (param1.scope.toString() != param2.scope.toString()) {
      status = false;
    } else if (param1.Capability.toString() != param2.Capability.toString()) {
      status = false;
    }
    else if (param1.LaborCategory.toString() != param2.LaborCategory.toString()) {
      status = false;
    }
    else if (param1.OtherRequirement.toString() != param2.OtherRequirement.toString()) {
      status = false;
    }
    else if (param1.Position.toString() != param2.Position.toString()) {
      status = false;
    }
    else if (param1.TechnicalRequirement.toString() != param2.TechnicalRequirement.toString()) {
      status = false;
    }
    else {
      status = true;
    }
    return status;

  }

}

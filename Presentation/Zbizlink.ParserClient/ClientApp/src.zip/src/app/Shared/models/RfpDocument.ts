export class RfpDocument {
    id: number;
    name: string;
    mappingTable: Element[];
  }
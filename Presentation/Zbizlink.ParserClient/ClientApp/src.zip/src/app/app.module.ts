import { BrowserModule } from '@angular/platform-browser';
import { NgModule, APP_INITIALIZER } from '@angular/core';
import {HttpClientModule} from '@angular/common/http';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { DocumentParserFormService} from './Parser/Shared/Services/document-parser-form.service';
import { NavMenuComponent } from './nav-menu/nav-menu.component';
import { HomeComponent } from './home/home.component';
import { FormsModule, ReactiveFormsModule}  from '@angular/forms';
import { EditorModule } from '@tinymce/tinymce-angular';
import { ValidateChangeInDataService } from './Parser/Shared/Services/ValidateChangeInDataService';
import { ParserModule } from './Parser/parser.module';
import { SharedModule } from './Shared/shared.module';
import { AppConfigService } from './Shared/services/app-config.service';


@NgModule({
  declarations: [
    AppComponent, 
    NavMenuComponent,
    HomeComponent
  ],
  imports: [
    BrowserModule,
    
    ParserModule,
    FormsModule,
    SharedModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    HttpClientModule,
    EditorModule,
  ],
  providers:[
    DocumentParserFormService,
    ValidateChangeInDataService,
    {
      provide: APP_INITIALIZER,
      multi: true,
      deps: [AppConfigService],
      useFactory: (appConfigService: AppConfigService) => {
        return () => {
          //Make sure to return a promise!
          return appConfigService.loadAppConfig();
        };
      }
    }
  ],

  bootstrap: [
    AppComponent
  ],
  entryComponents:[
  ]
})
export class AppModule { }

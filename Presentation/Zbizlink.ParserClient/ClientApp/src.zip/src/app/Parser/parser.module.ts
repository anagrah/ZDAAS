import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AddfieldDialogComponent } from './Components/addfield-dialog/addfield-dialog.component';
import { DocumentParserFormComponent } from './Components/document-parser-form/document-parser-form.component';
import { DocumentSummaryComponent } from './Components/document-summary/document-summary.component';
import { DocumentUploadComponent } from './Components/document-upload/document-upload.component';
import { DocumentListComponent } from './Components/document-list/document-list.component';

import { TinymceComponent } from './Components/tinymce/tinymce.component';

import { SharedModule } from '../Shared/shared.module';


@NgModule({
  imports: [
    CommonModule,
    SharedModule  
  ],
  declarations: [
    TinymceComponent,
    AddfieldDialogComponent,
    DocumentParserFormComponent,
    DocumentSummaryComponent,
    DocumentUploadComponent,
    DocumentListComponent
  ],
  exports: [
    
  ],
  entryComponents:[
    TinymceComponent,
    DocumentListComponent,
    AddfieldDialogComponent 
  ]
})
export class ParserModule { }

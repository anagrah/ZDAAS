import { Component, OnInit, ViewChild, Inject, Optional, Input } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { MatSort } from '@angular/material/sort';
import { DocumentParserFormService } from '../../Shared/Services/document-parser-form.service';

import { Observable } from 'rxjs';

import { DocumentParserFormComponent } from '../../../Parser/Components/document-parser-form/document-parser-form.component'

import { NotificationService } from '../../../Shared/services/notification.service';
import { map } from 'rxjs/operators';
import { Router } from '@angular/router';

export class PendingDocsList {
  RfpdocumentId: number;
  DocName: string;
  DueDate: Date;
  RemainingDays: number;
  Agency: string;

}

@Component({
  selector: 'app-document-list',
  templateUrl: './document-list.component.html',
  styleUrls: ['./document-list.component.css']
})
export class DocumentListComponent implements OnInit {

  @ViewChild(MatSort, { static: true }) sort: MatSort;
  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  oppertunityList: MatTableDataSource<any>;
  dataList: MatTableDataSource<any>;
  columnsToDisplay: string[] = ['DocName', 'DueDate', 'RemainingDays', 'Agency', 'action'];
  searchKey: string;
  popUpHeaderFlag: boolean;
  publishFlag: boolean = true;
  DocumentParserFormComponent: DocumentParserFormComponent;
  constructor(private router: Router, private documentParserForm: DocumentParserFormService,
    private notification: NotificationService,
    @Optional()
    public dialogRef: MatDialogRef<any>,
    @Optional()
    @Inject(MAT_DIALOG_DATA) data) {
    if (data) {
      this.popUpHeaderFlag = data.headerFlag;
      this.DocumentParserFormComponent = data.opportunityComponent;
      this.publishFlag = data.publish
    }
  }
  ngOnInit() {
    this.getPublicOppertunityList();
  }

  closeDialogOpp(): void {
    this.dialogRef.close();
  }

  remainingDays(value: string) {

    var todayDate = new Date();
    var diff = null;
    var diffDays = null;

    if (value != "") {
      if (new Date(value) > todayDate) {
        diff = Math.abs(new Date(value).getTime() - todayDate.getTime());
        diffDays = Math.ceil(diff / (1000 * 3600 * 24));
        return diffDays;
      }
      else {
        diff = Math.abs(new Date(value).getTime() - todayDate.getTime());
        diffDays = Math.ceil(diff / (1000 * 3600 * 24) - 365);
        return "-" + diffDays;
      }
    }
    else {
      return 0;
    }
  }
  actionHandler(id: number, actionName: string) {
    alert("Id:" + id + " , Action Name:" + actionName);
  }
  onSearchClear() {
    this.searchKey = "";
    this.applyFilter();
  }
  applyFilter() {
    this.oppertunityList.filter = this.searchKey.trim().toLowerCase();
  }
  getPublicOppertunityList() {
    this.documentParserForm.getPublicOppertunityList(this.publishFlag).subscribe(
      (response) => {

        var docList: Array<PendingDocsList> = [];
        docList = this.ExtractSummaryField(response);
        //console.log(response);

        // for(var dList in response.documentNameList)
        // {
        //   var pp = new PendingDocsList();
        //   //RfpdocumentId
        //   if(response.documentNameList[dList].Rfpsummary !== null && response.documentNameList[dList].Rfpsummary.length > 0){
        //     console.log(response.documentNameList[dList]);
        //   }

        //   pp.DocName = response.documentNameList[dList].DocName;
        //   pp.DueDate = Object.keys(response.documentNameList[dList].Rfpsummary).length > 0 ? response.documentNameList[dList].Rfpsummary[0].FieldValue : null;
        //   if(Object.keys(response.documentNameList[dList].Rfpsummary).length === 0)
        //   {
        //     pp.RemainingDays=0;
        //   }
        //   else
        //   {
        //     pp.RemainingDays=this.remainingDays(response.documentNameList[dList].Rfpsummary[0].FieldValue) > -1 ? this.remainingDays(response.documentNameList[dList].Rfpsummary[0].FieldValue):0;
        //   }
        //   pp.Agency= typeof response.documentNameList[dList].Rfpsummary[1].FieldValue==='undefined'?null:response.documentNameList[dList].Rfpsummary[1].FieldValue;
        //   pp.RfpdocumentId =  typeof response.documentNameList[dList].RfpdocumentId==='undefined'?null:response.documentNameList[dList].RfpdocumentId;
        //   docList.push(pp);
        // }
        docList.sort(d => d.RemainingDays)
        this.oppertunityList = new MatTableDataSource(docList);
        this.oppertunityList.sort = this.sort;
        debugger;
        this.oppertunityList.paginator = this.paginator;
      },
      (error: any) => {
        console.log(error);
        this.notification.error(error);
      }
    )
  }

  ExtractSummaryField(response: any): Array<PendingDocsList> {
    var docList: Array<PendingDocsList> = [];
    for (var dList in response.documentNameList) {
      var pp = new PendingDocsList();

      if (response.documentNameList[dList].Rfpsummary !== null && response.documentNameList[dList].Rfpsummary.length > 0) {
       
        pp.DueDate = Object.keys(response.documentNameList[dList].Rfpsummary).length > 0 ? response.documentNameList[dList].Rfpsummary[0].FieldValue : null;
        if (Object.keys(response.documentNameList[dList].Rfpsummary).length === 0) {
          pp.RemainingDays = 0;
        }
        else {
          pp.RemainingDays = this.remainingDays(response.documentNameList[dList].Rfpsummary[0].FieldValue) > -1 ? this.remainingDays(response.documentNameList[dList].Rfpsummary[0].FieldValue) : 0;
        }
        pp.Agency = typeof response.documentNameList[dList].Rfpsummary[1].FieldValue === 'undefined' ? null : response.documentNameList[dList].Rfpsummary[1].FieldValue;
      }
      pp.DocName = response.documentNameList[dList].DocName;     
      pp.RfpdocumentId = typeof response.documentNameList[dList].RfpdocumentId === 'undefined' ? null : response.documentNameList[dList].RfpdocumentId;
      docList.push(pp);
    }

    return docList;
  }

  loadOppertunity(RfpdocumentId: any) {
    console.log('>>>>>loadOppertunity<<<<<');

    this.DocumentParserFormComponent.getSavedDocInfo(null, null, RfpdocumentId);
    const queryParams = { 'category': 'summary' };
    this.router.navigate(['/'], { queryParams })
  }


}

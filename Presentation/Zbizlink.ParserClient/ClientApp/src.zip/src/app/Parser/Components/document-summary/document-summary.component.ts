import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { DocumentSummaryService } from '../../Shared/Services/document-summary.service';
import { NotificationService } from '../../../Shared/services/notification.service';
import { ValidateChangeInDataService } from '../../Shared/Services/ValidateChangeInDataService';
import { ActivatedRoute } from '@angular/router';
import { Summary } from 'src/app/Shared/models/Summary';

import { DatePipe } from '@angular/common';
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';

import { AddfieldDialogComponent } from '../addfield-dialog/addfield-dialog.component';//'./addfield-dialog/addfield-dialog.component';
import { SummaryField } from '../../Shared/models/SummaryField';
import { DocumentUploadComponent } from '../document-upload/document-upload.component';

@Component({
  selector: 'app-document-summary',
  templateUrl: './document-summary.component.html',
  styleUrls: ['./document-summary.component.css']
})
export class DocumentSummaryComponent implements OnInit {

  constructor(private fb: FormBuilder, private documentSummaryService: DocumentSummaryService
    , private notification: NotificationService,
    private validateChange: ValidateChangeInDataService,
    private dialog: MatDialog,
    private route: ActivatedRoute) {
  }
  private datePipe: DatePipe;
  groupForm: FormGroup;
  Test1: number = 20;
  ONE_DANK_REGEX = /^([0]{0,1}[1-9]|1[012])\/([1-9]|([012][0-9])|(3[01]))\/\d\d\d\d$|^([0]{0,1}[1-9]|1[012])-([1-9]|([012][0-9])|(3[01]))-\d\d\d\d$|^([0]{0,1}[1-9]|1[012])\/([1-9]|([012][0-9])|(3[01]))\/\d\d\d\d[ ]([0]{0,1}[1-9]|1[012]):([0-5][0-9])[ ](AM|PM|am|pm)$|^([0]{0,1}[1-9]|1[012])-([1-9]|([012][0-9])|(3[01]))-\d\d\d\d[ ]([0]{0,1}[1-9]|1[012]):([0-5][0-9])[ ](AM|PM|am|pm)$|^(January|February|March|April|May|June|July|August|September|October|November|December|Jan|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[ ]([1-9]|[1-2][0-9]|3[0-1])[,][ ](20)[0-9]{2}$|^(January|February|March|April|May|June|July|August|September|October|November|December)[ ](0[1-9]|[1-9]|[1-2][0-9]|3[0-1])[,][ ](20)[0-9]{2}[ ]([1-9]|(?=[0-1])[0-1][0-9]|(?=2)2[0-4]):([0-5][0-9])[ ](AM|PM|am|pm)$|^(January|February|March|April|May|June|July|August|September|October|November|December)[ ](0[1-9]|[1-9]|[1-2][0-9]|3[0-1])[,][ ](20)[0-9]{2}[ ][ ]([1-9]|(?=[0-1])[0-1][0-9]|(?=2)2[0-4]):([0-5][0-9])[ ](AM|PM|am|pm)$/;
  //....................
  summarArray: Array<SummaryField>;
  try(): boolean { return true; }

  ngOnInit() {
    this.groupForm = this.fb.group({});
    this.summarArray = new Array<SummaryField>();
  };

  createGroup(summaryFieldArray: Array<SummaryField>) {
  
    if (summaryFieldArray != undefined) {
      // this.groupForm.reset();
      this.summarArray = summaryFieldArray;

      this.validateChange.initDataSummary(summaryFieldArray, null);
      this.drawFields(summaryFieldArray);
      // console.log(this.groupForm);
    };
  };

  drawFields(summaryFieldArray) {
    this.removeControlIfExist(this.groupForm);
    summaryFieldArray.forEach(

      control => {
        //console.log('>>>>>>'+control.FiledTypeId+'<<<<<');
        if (control.FieldDisplayName == "Solicitation Title") {
          this.groupForm.addControl(control.FieldDisplayName, this.fb.control(control.FieldText, [Validators.required, Validators.maxLength(250)]))
        } else if (control.FieldDisplayName == "Solicitation Number") {
          this.groupForm.addControl(control.FieldDisplayName, this.fb.control(control.FieldText, [Validators.required, Validators.maxLength(50)]))

        } else if (control.FieldDisplayName == "Requesting Agency") {
          this.groupForm.addControl(control.FieldDisplayName, this.fb.control(control.FieldText, [Validators.required, Validators.maxLength(250)]))
        }
        else if (control.FieldDisplayName == "Original Posted Date") {
          this.groupForm.addControl(control.FieldDisplayName, this.fb.control(control.FieldText, [Validators.required, Validators.pattern(this.ONE_DANK_REGEX)]))
        }
        else if (control.FieldDisplayName == "Question Due Date") {
          this.groupForm.addControl(control.FieldDisplayName, this.fb.control(control.FieldText, [Validators.pattern(this.ONE_DANK_REGEX)]))
        }
        else if (control.FieldDisplayName == "Pre-bid Date") {
          this.groupForm.addControl(control.FieldDisplayName, this.fb.control(control.FieldText, [Validators.pattern(this.ONE_DANK_REGEX)]))
        }
        else if (control.FieldDisplayName == "Closing Date and Time") {
          this.groupForm.addControl(control.FieldDisplayName, this.fb.control(control.FieldText, [Validators.required, Validators.pattern(this.ONE_DANK_REGEX)]))
        }
        else if(control.FiledTypeId=="3")
        {
          this.groupForm.addControl(control.FieldDisplayName, this.fb.control(control.FieldText, [Validators.pattern(this.ONE_DANK_REGEX)]))
        }
        else 
        {
          this.groupForm.addControl(control.FieldDisplayName, this.fb.control(control.FieldText, [Validators.maxLength(250)]))
        }
      }

    );
  }
  removeControlIfExist(group: FormGroup): void {
    Object.keys(group.controls).forEach((key: string) => {
      const abstractControl = group.get(key);
      group.removeControl(key);
    });
  }


   addField(index:number, summaryField: SummaryField) {
   let fieldTypeId: number;
    if (summaryField.ControlType.toString() == 'TextBox') {
      summaryField.FiledTypeId = 1;
      summaryField.ControlType = 'text';
    } else if (summaryField.ControlType.toString() == 'textarea') {
      fieldTypeId = 2;
    } else {
      summaryField.FiledTypeId = 3;
      summaryField.ControlType = 'date';
    }

    this.summarArray.splice(index + 1,0,summaryField);
    this.summarArray.forEach(
      control => 
      {
          //console.log('>>>>>> fieldID >>>>'+control.FiledTypeId+'<<<<<');
          if(control.FiledTypeId === 3)
          {
            this.groupForm.addControl(control.FieldDisplayName, this.fb.control(control.FieldText, [Validators.pattern(this.ONE_DANK_REGEX)]))
          }
          else
          {
            this.groupForm.addControl(control.FieldDisplayName, this.fb.control(control.FieldText, [Validators.maxLength(250)]))
          }
      }
    );
  }

  openDialog(e, index) {
  
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.width = '500px';
    dialogConfig.height = '300px';

    //console.log('---------------');
    dialogConfig.data = {
      id: index,
      summary: this
    };
    const dialogRef = this.dialog.open(AddfieldDialogComponent, dialogConfig);

    dialogRef.afterClosed().subscribe(
      summaryField => {
        if (summaryField !== undefined)
        {
                  this.addField(index,summaryField);
        }
      });
  }

  deleteField(index) {
    let deletedElement = this.summarArray[index];
    this.summarArray.splice(index, 1);
    this.groupForm.removeControl(deletedElement.FieldDisplayName);
  }

  async onSubmit(documentUpload: DocumentUploadComponent, isOpportunity: boolean, categoryId: string, documentId: string) {
    // this.mapFormValuesToSummaryModel();
    let createedOpportunity = false;
    if (isOpportunity == true) {
      createedOpportunity = true;
    }
    let fieldTextString = "";
    let summaryObjArray = [];
    //let fieldsValidated = this.SummaryFieldValidation();
    let fieldsValidated = this.SummaryFieldValid();

    Object.keys(this.groupForm.controls).forEach((key: string) => {
      const abstractControl = this.groupForm.get(key);
      // console.log('Key = ' + key + ' && Value = ' + abstractControl.value);
      let summaryIndex: number = this.summarArray.findIndex(el => el.FieldDisplayName == key);
      let summary = this.summarArray[summaryIndex];
      let summaryObj = { key: key, Value: abstractControl.value, DisplayOrder: summaryIndex + 1, FiledTypeId: summary.FiledTypeId }  //console.log(abstractControl.value);
      summaryObjArray.push(summaryObj);
      fieldTextString += abstractControl.value;
    });

    if (fieldsValidated) {
      if (!this.validateChange.isEqualSummary(fieldTextString, this.summarArray)) {
        createedOpportunity = false;
        documentUpload.isLoadingSmall = true;
        await this.SaveSummary(documentUpload, isOpportunity, documentId, fieldTextString, summaryObjArray);
      }
      if (isOpportunity == true && createedOpportunity == true) {
        documentUpload.publish();
      }
    }
  }

  async SaveSummary(documentUpload: DocumentUploadComponent, isOpportunity: boolean, documentId: string, fieldTextString: string, summaryObjArray = []) {

    const formData = new FormData();
    if (documentId && summaryObjArray.length > 0) {
      formData.append('documentId', documentId);
      formData.append('summary', JSON.stringify(summaryObjArray));
    }

    this.documentSummaryService.addSummary(formData).subscribe((response) => {

      if (response.status != "error") {
        this.notification.success("Summary has been successfully saved.");
        this.validateChange.initDataSummary(this.summarArray, fieldTextString);
        documentUpload.isLoadingSmall = false;
        if (isOpportunity == true) {
          documentUpload.publish();
        }
      } else {
        documentUpload.isLoadingSmall = false;
        this.notification.error(response.message);
      }
    },
      (error: any) => {
        documentUpload.isLoadingSmall = false;
        this.notification.error(error);

      });
  }

  SummaryFieldValid() : boolean{
      
    return this.groupForm.valid;

  }

  MaxlengthErrorMessage(fieldName: string): string {

    let errorMessage: string = "";

    if (this.groupForm.get(fieldName).errors != null &&
      this.groupForm.get(fieldName).errors.maxlength != null &&
      this.groupForm.get(fieldName).errors.maxlength.requiredLength != null) {
        errorMessage = fieldName + ' must be less than ' + this.groupForm.get(fieldName).errors.maxlength.requiredLength + ' character';
    }
    return errorMessage;
  }

  InvalidDateErrorMessage(fieldName:string):string{
    let errorMessage: string = "";
    if (this.groupForm.get(fieldName).errors.pattern!=null) {
      //console.log(fieldName);
        errorMessage = 'Date format must be like mm/dd/yyyy or mm-dd-yyyy or July 8, 2018 00:00 PM';
    }
    return errorMessage;
  }
}

import { Component, OnInit, Output, EventEmitter, Input, ViewChild } from '@angular/core';
import { ActivatedRoute, Router, Event, NavigationStart, NavigationEnd, NavigationError } from '@angular/router';
import { DocumentParserFormService } from '../../Shared/Services/document-parser-form.service';
import { FormGroup, FormControl } from '@angular/forms';
import { DocumentSummaryComponent } from '../../../Parser/Components/document-summary/document-summary.component';//'../opportunity/summary/summary.component';
//import { debug } from 'util';
import { NotificationService } from '../../../Shared/services/notification.service';
import { ValidateChangeInDataService } from '../../Shared/Services/ValidateChangeInDataService';
import { DocUploadResponse } from '../../Shared/models/DocUploadResponse';
import { Summary } from '../../../Shared/models/Summary';
import { SharePointDocUploadResponse } from 'src/app/Shared/models/SharePointDocUploadResponse';
declare function transfertoZbizlink(): any;
declare function transfertoZbizlinkData(data): any;

@Component({
  selector: 'app-document-upload',
  templateUrl: './document-upload.component.html',
  styleUrls: ['./document-upload.component.css']
})
export class DocumentUploadComponent implements OnInit {

  @Input()
  fileName
  @Output()
  receivedRFPDocument: EventEmitter<any> = new EventEmitter<any>();
  @Output()
  receivedRFPDocumentName: EventEmitter<string> = new EventEmitter<string>();
  @Input()
  opportunityData: Element[];
  @Input()
  summary: DocumentSummaryComponent;
  // @Input()
  // documentName:string;
  isBtnPubDisabled: boolean;

  docUploadResponse: DocUploadResponse = new DocUploadResponse();
  @Output()
  oppPopUpGrid: EventEmitter<DocUploadResponse> = new EventEmitter<DocUploadResponse>();
  @Output() ClearOpportunityForm: EventEmitter<any> = new EventEmitter();

  isLoadingSmall: boolean = false;
  isLoading: boolean = false;
  //fileName: string;
  file: any;
  RfpDataArray: Element[] = [];
  profileForm: FormGroup;
  uploadError: string;
  saveError: string;
  rfpDocument: string;
  categoryName: string;
  //formGroupCB:FormGroup;
  private: string; // radioButton
  documentPublished: boolean;
  responseSave: boolean = false;
  isPublish: boolean = false;
  ONE_DANK_REGEX = /^([0]{0,1}[1-9]|1[012])\/([1-9]|([012][0-9])|(3[01]))\/\d\d\d\d$|^([0]{0,1}[1-9]|1[012])-([1-9]|([012][0-9])|(3[01]))-\d\d\d\d$|^([0]{0,1}[1-9]|1[012])\/([1-9]|([012][0-9])|(3[01]))\/\d\d\d\d[ ]([0]{0,1}[1-9]|1[012]):([0-5][0-9])[ ](AM|PM|am|pm)$|^([0]{0,1}[1-9]|1[012])-([1-9]|([012][0-9])|(3[01]))-\d\d\d\d[ ]([0]{0,1}[1-9]|1[012]):([0-5][0-9])[ ](AM|PM|am|pm)$|^(January|February|March|April|May|June|July|August|September|October|November|December|Jan|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[ ]([1-9]|[1-2][0-9]|3[0-1])[,][ ](20)[0-9]{2}$|^(January|February|March|April|May|June|July|August|September|October|November|December)[ ](0[1-9]|[1-9]|[1-2][0-9]|3[0-1])[,][ ](20)[0-9]{2}[ ]([1-9]|(?=[0-1])[0-1][0-9]|(?=2)2[0-4]):([0-5][0-9])[ ](AM|PM|am|pm)$|^(January|February|March|April|May|June|July|August|September|October|November|December)[ ](0[1-9]|[1-9]|[1-2][0-9]|3[0-1])[,][ ](20)[0-9]{2}[ ][ ]([1-9]|(?=[0-1])[0-1][0-9]|(?=2)2[0-4]):([0-5][0-9])[ ](AM|PM|am|pm)$/;
  //receivedRFPDocument: EventEmitter<any> = new EventEmitter<any>();

  fileUpload = { status: '', category: [], document: '', filePath: '', summary: '', documentId: '', documentName: '', CategoryData: '', message: '' };
  constructor(private router: Router, private documentParserFormService: DocumentParserFormService, private route: ActivatedRoute,
    private notification: NotificationService,
    private validateChange: ValidateChangeInDataService) {

  }

  ngOnInit() {

    // this.formGroupCB = new FormGroup({
    //   private:new FormControl()
    // });
    this.isBtnPubDisabled = true;
    this.private = "1";
  }

  getRouteParam(): void {
    this.route.queryParamMap.subscribe(params => {
      this.categoryName = params.get('category');
    });
  }

  onSelectedFile(event) {

    this.uploadError = "";

    if (event.target.files.length < 1) {
      return false;
    }

    this.file = event.target.files[0];
    this.fileName = this.file.name;

    event.target.value = '';

    if(!this.FileValidation()){ 
    // var reg = /(.*?)\.(doc|docx|pdf)$/;
    // if (!this.fileName.match(reg)) {
    //   this.file = undefined;
    //   this.uploadError = 'Please upload file having extensions .doc/.docx/.pdf only.';
    //   this.notification.warning(this.uploadError);
       return false;
    }
    else {
      // this.fileName = "";
      //this.RfpDataArray = [];
      //this.file = event.target.files[0];
      //this.fileName = this.file.name;
      //this.fileUpload.documentName=this.file.name
      
      
      this.receivedRFPDocumentName.emit(this.file.name);
      //this.receivedRFPDocument.emit([null,null,null,null, this.file.name]);
    }

  }

  click(): void {
    this.uploadError = "";
    this.RfpDataArray = [];
  }

  async upload() {
    this.ClearOpportunityForm.emit(null);
    if (this.file === undefined) {
      this.uploadError = "Select file for uploading";
      this.isLoading = false;
      this.notification.warning(this.uploadError);
      return;
    }
    this.uploadError = "";
    this.isBtnPubDisabled = true;
    this.isLoading = true;
    this.RfpDataArray = [];
    debugger;
    if (localStorage.getItem('userid') != null && localStorage.getItem('compId') != '0' && localStorage.getItem('userid') != '0') {
      //Invoke webservice to upload document over sharepoint
      const formDataSharePoint = new FormData();
      console.log(localStorage.getItem('compId'));
      formDataSharePoint.append('CompanyId', localStorage.getItem('compId'));
      console.log(localStorage.getItem('userid'));
      formDataSharePoint.append('UserId', localStorage.getItem('userid'));
      console.log(localStorage.getItem('clientID'));
      formDataSharePoint.append('ClientId', localStorage.getItem('clientID'));
      console.log(localStorage.getItem('companySegmentID'));
      formDataSharePoint.append('SegmentId', localStorage.getItem('companySegmentID'));
      formDataSharePoint.append('File', this.file);
      this.documentParserFormService.uploadSharePoint(formDataSharePoint).subscribe(
        res => this.SharePointUploadResponse(res),
        err => this.UploadError(err)
      );
    }
    else {
      const formData = new FormData();
      formData.append('file', this.file);
      formData.append('companyID', '');
      formData.append('userId', '');
      formData.append('clientId', '');
      formData.append('SegmentId', '');
      formData.append('filepath', '');
      this.documentParserFormService.upload(formData).subscribe(
        res => this.UploadReponse(res),
        err => this.UploadError(err)
      );
    }
  }

  SharePointUploadResponse(obj: SharePointDocUploadResponse): void {
    console.log(obj.Status);
    if (obj.Status === 'successed') {
      const formData = new FormData();
      formData.append('file', this.file);
      formData.append('companyID', localStorage.getItem('compId'));
      formData.append('clientId', localStorage.getItem('clientID'));
      formData.append('userId', localStorage.getItem('userid'));
      formData.append('SegmentId', localStorage.getItem('companySegmentID'));
      formData.append('filepath', obj.FilePath);
      this.documentParserFormService.upload(formData).subscribe(
        res => this.UploadReponse(res),
        err => this.UploadError(err)
      );
    }
  }

  UploadReponse(docUploadResponse: DocUploadResponse): void {
    debugger;
    if (docUploadResponse.status === "1") {
      this.documentPublished = false;
      localStorage.setItem('documentId', docUploadResponse.documentId);
      docUploadResponse.documentName = this.fileName;
      this.receivedRFPDocument.emit(docUploadResponse);
      this.isLoading = false;
      this.notification.success("File uploaded successfully !");
      this.isBtnPubDisabled = false;
      const queryParams = { 'category': 'summary' };
      this.router.navigate(['/'], { queryParams })
    } else if (docUploadResponse.status === "2") {
      this.isLoading = false;
      this.notification.warning(docUploadResponse.message);
    } else if (docUploadResponse.status === "0") {
      this.isLoading = false;
      this.notification.error("'Something bad happened. Please try again later.'");
    } else {
      if (docUploadResponse.status !== undefined) {
        this.isLoading = false;
        this.notification.error("'Something bad happened. Please try again later.'");
      }
    }

  }

  UploadError(parm: any): void {
    this.uploadError = parm;
    this.isLoading = false;
    this.notification.error(this.uploadError);
  }

  async doPublish(isOpportunity: boolean) {
    debugger;
    if (this.responseSave === false) {
      await this.Save(isOpportunity);
    }
    else {
      this.isPublish = true;
    }
    console.log("----" + this.responseSave + "---");
  }

  async Save(isOpportunity: boolean) {
    //console.log("Save");
    //console.log('>>>>>>>>>>>> clicked <<<<<<<<<<<<'+isOpportunity);
    this.responseSave = true;
    if (isOpportunity === false) {

      let createOpporturnity: boolean = false;
      let categoryId: string = this.GetCategoridIdFromQueryparameter();
      let documentId = localStorage.getItem('documentId');
      if (categoryId && documentId && categoryId != 'summary') {

        let categoryData = this.CategoryDataConvertArrayIntoString();
        if (!this.validateChange.isEqual(categoryData)) {
          createOpporturnity = false;
          this.isLoadingSmall = true;
          await this.SaveCategory(categoryData, documentId, categoryId, isOpportunity);
          this.isLoadingSmall = false;
        }
      }
      else if (this.summary.SummaryFieldValid() && (categoryId == 'summary' || categoryId == null)) {

        await this.summary.onSubmit(this, isOpportunity, categoryId, documentId);
      }
    }
    else if (isOpportunity === true) {
    let SummaryFieldValidationResult = this.SummaryFieldValidation()
      if (SummaryFieldValidationResult && isOpportunity === true) {
        this.isBtnPubDisabled = true;
        this.isLoading = true;

        let createOpporturnity: boolean = false;
        if (isOpportunity == true) {
          createOpporturnity = true;
        }

        let categoryId: string = this.GetCategoridIdFromQueryparameter();

        let documentId = localStorage.getItem('documentId');

        if (categoryId && documentId && categoryId != 'summary') {

          let categoryData = this.CategoryDataConvertArrayIntoString();

          if (!this.validateChange.isEqual(categoryData)) {
            createOpporturnity = false;
            this.isLoadingSmall = true;
            await this.SaveCategory(categoryData, documentId, categoryId, isOpportunity);
          }

          if (isOpportunity == true && createOpporturnity == true) {
            this.publish();
          }

        }
        else if (categoryId == 'summary' || categoryId == null) {

          this.summary.onSubmit(this, isOpportunity, categoryId, documentId);

        }
      }
      else if (!SummaryFieldValidationResult && isOpportunity === true) {
        //console.log('navigate it now');
        const queryParams = { 'category': 'summary' };
        this.router.navigate(['/'], { queryParams })
        this.isLoading = false;
        this.responseSave = false;
        return;
      }
    }
    if (this.isPublish === true) {
      this.isPublish = false;
      await this.Save(true);
      console.log("published");
    }
    this.responseSave = false;
  }


  oppPopUpGridHandler(): void { // open the dialogue in oppertunity componenet 

    localStorage.setItem('pendinglist', 'clicked');
    this.oppPopUpGrid.emit();
  }

  getOpportunity() {
    debugger;
    this.documentParserFormService.getOpportunity().subscribe(
      (response) => {
        transfertoZbizlinkData(response);
      },
      (error: any) => {
        console.log(error);
        this.notification.error(error);
      }
    )
  }

  publish(): void {
    let documentId = localStorage.getItem('documentId');
    //*************Loader********
    //this.isLoading = true;
    //**************************
    this.isBtnPubDisabled = true;
    this.documentParserFormService.publish(documentId).subscribe(
      (response) => {
        try {
          if (response.Status == "1") {
            this.notification.success("Oppertunity publlished succefully ");
            this.isLoading = false;
            this.documentPublished = true;
            transfertoZbizlinkData(response);
          } else if (response.Status == "-1") {
            this.notification.success("Oppertunity creation process fail");
            this.isLoading = false;
            this.isBtnPubDisabled = false;
            this.documentPublished = false;
          }

        } catch (err) {
          this.isLoading = false;
          this.isBtnPubDisabled = false;
          this.documentPublished = false;
          console.log(err);
        }

      },
      (error: any) => {
        this.isLoading = false;
        this.isBtnPubDisabled = false;
        this.documentPublished = false;
        this.notification.error(error);
      }
    )
  }


  async SaveCategory(CategoryData: string, documentId: string, categoryId: string, isOpportunity: boolean) {

    const formData = new FormData();
    formData.append('documentId', documentId);
    formData.append('categoryId', categoryId);
    formData.append('categoryData', CategoryData);
    formData.append('summary', null);

    this.documentParserFormService.save(formData).subscribe((response) => {

      if (response.status != "error") {
        this.isLoadingSmall = false;
        this.notification.success("Your data has been successfully saved.");
        if (isOpportunity == true) {
          this.publish()
        }
      }
      else {
        this.isLoadingSmall = false;
        this.notification.error(response.message);
      }
    },
      (error: any) => {

        this.isLoadingSmall = false;
        this.notification.error(error);

      });
  }

  CategoryDataConvertArrayIntoString(): string {

    let rfpDoc: string = "";
    for (let index = 0; index < this.opportunityData.length; index++) {
      const element = this.opportunityData[index];
      if (element.getAttribute("data-lastrow") == null || element.getAttribute("data-lastrow").valueOf().trim() != ".") {
        rfpDoc += element.outerHTML;
      }
    }
    return rfpDoc;
  }

  GetCategoridIdFromQueryparameter(): string {

    let categoryId: string;
    this.route.queryParamMap.subscribe(params => {
      if (params.has('category')) {
        categoryId = params.get('category');
      }
    });
    return categoryId;
  }

  SummaryFieldValidation(): boolean {
    let result = this.summary.SummaryFieldValid();
    if (!result) {
      this.notification.error("One or more fields are required");
      return false;
    }
    return true;
  }
  FileValidation(): boolean{

    let reg = /(.*?)\.(doc|docx|pdf)$/;
    let filename: string = this.file.name;
    if (!filename.match(reg)) {
      this.file = undefined;
      this.uploadError = 'Please upload file having extensions .doc/.docx/.pdf only.';
      this.notification.warning(this.uploadError);
      return false;
    }
    if(filename.includes("&") || filename.includes("#")){
      this.file = undefined;
      this.uploadError = 'File name must not contain special character, (& , #)';
      this.notification.warning(this.uploadError);
      return false;
    }
    return true;
  }
}

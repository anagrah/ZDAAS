import { Component, OnInit, ViewChild, ViewEncapsulation, PipeTransform, Pipe, ElementRef, Input } from '@angular/core';
import { DocumentParserFormService } from '../../Shared/Services/document-parser-form.service';
import { DragulaService } from 'ng2-dragula';
import { ContextMenuComponent } from 'ngx-contextmenu';
import { Subscription} from 'rxjs';
import { ActivatedRoute, Router, Event, NavigationStart, NavigationEnd, NavigationError } from '@angular/router';
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';
import { TinymceComponent } from '../tinymce/tinymce.component';
import { InsertCategoryAttributeService } from '../../../shared/services/insert-category-attribute.service';
import { DocumentUploadComponent } from '../document-upload/document-upload.component';
import { DocumentSummaryComponent } from '../document-summary/document-summary.component';
import { SummaryField } from '../../Shared/Models/SummaryField';
import { DocumentListComponent } from '../document-list/document-list.component';
import { NotificationService } from '../../../Shared/services/notification.service';
import { ValidateChangeInDataService } from '../../Shared/Services/ValidateChangeInDataService';
import { OppertunityCategory } from '../../../Shared/models/OppertunityCategory';
import { DocUploadResponse } from '../../Shared/models/DocUploadResponse';




@Component({
  selector: 'app-document-parser-form',
  templateUrl: './document-parser-form.component.html',
  styleUrls: ['./document-parser-form.component.css']
})
export class DocumentParserFormComponent implements OnInit {

  isLoading: boolean = false;
  isSummary: boolean = false;
  @ViewChild(DocumentSummaryComponent, { static: true }) documentSummaryComponent: DocumentSummaryComponent;
  @ViewChild(ContextMenuComponent, { static: true }) public basicMenu: ContextMenuComponent;
  @ViewChild(DocumentUploadComponent, { static: true }) documentUploadComponent: DocumentUploadComponent;
  subs = new Subscription();


  //fileUploadComponent: FileUploadComponent;
  category: string;
  categoryArray: Array<any> = [];
  categoryName: string;
  catValues: Array<any> = [];
  RfpDataArray: Element[] = [];
  
  filteredOpportunityDataArray: Element[] = [];

  summaryFieldArray: Array<SummaryField>;
  documentID: string;
  documentName: string;
  //.....
  CategoryData: Array<any>;
  oppertunityCategoryArray: Array<OppertunityCategory>; // new by Nisar

  constructor(private route: ActivatedRoute,
    private documentParserFormService: DocumentParserFormService,
    private dragulaService: DragulaService,
    private dialog: MatDialog,
    private insertCategoryAttributeService: InsertCategoryAttributeService,
    private router: Router,
    private notification: NotificationService,
    private validateChange: ValidateChangeInDataService) 
    {
    this.categoryArray = []
    this.oppertunityCategoryArray = new Array<OppertunityCategory>();
    router.events.subscribe(
      (event: Event) => {
        if (event instanceof NavigationStart) {
          // Show loading indicator
        }
        if (event instanceof NavigationEnd) {

         
        }
        if (event instanceof NavigationError) {

        
        }
      });
    //................
  };

  documentId: string; // temp


  ngOnInit() {
    this.dragulaConfig();
    this.RouteParam();
    this.getRoutParamsBizlink();
    this.documentId = localStorage.getItem('documentId');

  }

  getRoutParamsBizlink(): void {

    let companyid = "";
    let userid = "";
    let rfpdocumentid = "";
    this.route.queryParamMap.subscribe(params => {
      //console.log('>>>>>getRoutParamsBizlink<<<<<');
      if (params.has('companyid') && params.has('userid') && !params.has('rfpdocumentid') && !params.has('companySegmentID')) {
        companyid = params.get('companyid');
        userid = params.get('userid');
        // alert("*******  Welcome *******  \n You're landing from Bizlink with ! \n  company Id = "+companyid +"user Id = "+ userid);
        //console.log('>>>>>getRoutParamsBizlink>>call 1<<<<<');
        this.getSavedDocInfo(companyid, userid, null);
      }
      else if (params.has('rfpdocumentid')) {
        rfpdocumentid = params.get('rfpdocumentid');
        //console.log('>>>>>getRoutParamsBizlink>>call 2<<<<<');
        this.getSavedDocInfo(null, null, rfpdocumentid);
      }
    });

  }

  activeClass(cat) {
    //console.log(cat);
    cat.active = true;
  }

  onRfpDocumentNameReceived(docName: string): void {
    this.documentName = docName;
  }

  onRfpDocumentReceived(docUploadResponse: DocUploadResponse): void {
    this.ClearForm();
    this.documentName = docUploadResponse.documentName;// rfpDocument[4];
    this.categoryArray = docUploadResponse.category;// rfpDocument[1];
    let data: string = docUploadResponse.document;// rfpDocument[0];
    this.summaryFieldArray = docUploadResponse.summary;// rfpDocument[2];
    this.documentID = docUploadResponse.documentId;// rfpDocument[3];
    this.documentName = docUploadResponse.documentName;// rfpDocument[4];
    this.CategoryData = docUploadResponse.CategoryData;// rfpDocument[5];
    this.LoadRfpData(data, "fromFileUpload");
    this.documentSummaryComponent.createGroup(this.summaryFieldArray);
    this.fillOppeCatArray(this.categoryArray, this.CategoryData);
    this.RouteParam();
    //}
    //}
  }



  fillOppeCatArray(categoryArray: Array<any>, CategoryData: Array<any>) {

    let self = this;
    if (categoryArray != null && categoryArray.length > 0) {
      if (this.oppertunityCategoryArray.length > 0) {
        this.oppertunityCategoryArray.length = 0
        this.oppertunityCategoryArray = [];
      }

      
      categoryArray.forEach(cat => {

        let ObjOppCat = new OppertunityCategory();
        ObjOppCat.categoryId = null;
        ObjOppCat.categoryName = null;

        if (ObjOppCat.categoryData) { ObjOppCat.categoryData.length = 0; ObjOppCat.categoryData = []; }

        ObjOppCat.categoryId = cat.CategoryId;
        ObjOppCat.categoryName = cat.Name;

        let data: any = {};

        if (CategoryData) {

          data = CategoryData.filter((item) => {
            if (item.CategoryId == cat.CategoryId) return item.CategoryData;
          }).shift();
          if (data != undefined) {
          //  debugger;
            ObjOppCat.categoryData = this.RestDataIndexAttribute(data.CategoryData, cat.CategoryId);
            
            self.oppertunityCategoryArray.push(ObjOppCat);
          } else {
            ObjOppCat.categoryData = this.CreateElementForEmptyCategory(ObjOppCat.categoryId);
            self.oppertunityCategoryArray.push(ObjOppCat);
          }
        }
      });
    }
  }

  dragulaConfig() {

    let newAddElement: Element;
    let siblingOfNewAddElement: Element;
    let isNewElement: Boolean;
    let sourceIndexId:number;
    let targetIndexId:number;
    let sourceId:string;
    let siblingCopy:Element;
    let isCopied:boolean;
    this.dragulaService.createGroup('Copy', {
      direction: 'horizontal',
      copy: (element: Element, source) => {
        
        console.log(source.id);
        return source.id === 'left';
      },

      copyItem: (element: Element) => {
        console.log("copyItem");
        console.log(element);
        isNewElement = true;
        element.setAttribute("data-new", "true");
        return <Element>element.cloneNode(true);
      },

      accepts: (el, target, source, sibling) => {
        console.log("accept");
        console.log(target.id);
          return target.id !== 'left';
        
      }
    });
    
    

    this.subs.add(this.dragulaService.dropModel("Copy")
      .subscribe(({ name,
        el,
        target,
        source,
        sibling,
        item,
        sourceModel,
        targetModel,
        sourceIndex,
        targetIndex }) => {

        if(source.id == 'right'){
            //console.log("Source Index >>>>> "+sourceIndex);
            //console.log("target Index >>>>> "+targetIndex);
            sourceIndexId = sourceIndex;
            targetIndexId = targetIndex;
            sourceId = source.id;
            siblingCopy = sibling;
            isCopied=true;
        }
        siblingOfNewAddElement = sibling;
      })
    );

    this.subs.add(this.dragulaService.dragend("Copy")
      .subscribe(({ name, el}) => {
        //console.log("dragend");
        if (isNewElement === true) {
       
          newAddElement = el.querySelector("div *");
          this.ResetOppertunityDataListNewAddElement(newAddElement, siblingOfNewAddElement);
          isNewElement = false;
        }else{
        
            
        //debugger;
            if(sourceId == 'right' && isCopied===true){
              isCopied=false;
              this.copyNodes(sourceIndexId,targetIndexId,siblingCopy,el);
            }
        }
      })
    );
  }

  copyNodes(sourceIndex,targetIndex,sibling,el)
  {
    //debugger;
      if(sourceIndex > targetIndex)  
      {
          let asibling = sibling.querySelector("div *");
          let siblingIndex = asibling.getAttribute("data-index").valueOf();
          // console.log(">>>>>>Sibling Index -->"+ siblingIndex +"<--<<<<<<");
          let siblingNode = this.filteredOpportunityDataArray.find(n => n.getAttribute("data-index").valueOf() === siblingIndex);
          // console.log("Sibling Node"+ siblingNode);
          let index = this.filteredOpportunityDataArray.indexOf(siblingNode);
          var diffIndex = sourceIndex - targetIndex;
          var getsiblingIndex:number = +index;
          var getsourceIndex = getsiblingIndex + diffIndex;
          var gettargetIndex:number = +index;
          if(gettargetIndex >=0)
          {
            //console.log(getsourceIndex);
            //console.log(this.filteredOpportunityDataArray.length);
            //console.log(index);
            var newAddElementCopy = el.querySelector("div *");
            this.ResetOppertunityDataListCopyElement(newAddElementCopy, sibling ,diffIndex,true);
            //console.log(newAddElementCopy);
            let finalNewElement = this.insertCategoryAttributeService.resetOpportunityData(this.filteredOpportunityDataArray, this.filteredOpportunityDataArray.length, this.categoryName);
            this.resetDataIndexAttr();
            this.pushIntoFilteredArray();
          }
      }
      else
      {
        //console.log(sibling);
        
          if(sibling !=null)
          {
            let asibling = sibling.querySelector("div *");
            let siblingIndex = asibling.getAttribute("data-index").valueOf();
            // console.log(">>>>>>Sibling Index -->"+ siblingIndex +"<--<<<<<<");
            let siblingNode = this.filteredOpportunityDataArray.find(n => n.getAttribute("data-index").valueOf() === siblingIndex);
            // console.log("Sibling Node"+ siblingNode);
            let index = this.filteredOpportunityDataArray.indexOf(siblingNode);
            var diffIndex = targetIndex - sourceIndex;
            // console.log(diffIndex);
            var getsiblingIndex:number = +index;
            var getsourceIndex = getsiblingIndex - (diffIndex + 1);
            var gettargetIndex = getsiblingIndex;
            //console.log(getsourceIndex);
            //console.log(getsiblingIndex);
            //console.log(index);
            var newAddElementCopy = el.querySelector("div *");
            this.ResetOppertunityDataListCopyElement(newAddElementCopy, sibling,diffIndex,false);
           
        }
        else
        {
          el.setAttribute("data-new", "true");
          var newAddElementCopy = el.querySelector("div *");
          var diffIndex = targetIndex - sourceIndex;
          if(this.filteredOpportunityDataArray.length > 15)
          {
            this.filteredOpportunityDataArray.splice(this.filteredOpportunityDataArray.length,0,newAddElementCopy);
            this.filteredOpportunityDataArray.splice(this.filteredOpportunityDataArray.length-(diffIndex+2) ,1);
          }
          else
          {
            this.filteredOpportunityDataArray.splice(this.filteredOpportunityDataArray.length,0,newAddElementCopy);
            this.filteredOpportunityDataArray.splice(this.filteredOpportunityDataArray.length-1 ,1);
          }
            newAddElementCopy.removeAttribute("data-new");
            let finalNewElement = this.insertCategoryAttributeService.resetOpportunityData(this.filteredOpportunityDataArray, this.filteredOpportunityDataArray.length, this.categoryName);
            this.resetDataIndexAttr();
            this.pushIntoFilteredArray();
        }
      }
  }
  ResetOppertunityDataListCopyElement(newAddElement: Element, sibling: Element,diffIndex:number,direction:boolean): void {
    //debugger;
             
    let addNodeIndex = this.filteredOpportunityDataArray.findIndex(line => line.getAttribute("data-new") == "true");
    //console.log(">>>>>>add node index--"+ addNodeIndex+"--<<<<<<");
    
  
    let index: number;
    let indexSibling:number;
    let indexInArr = 0;
    let getsiblingIndex:number;
    if(sibling != null)
    {
      let asibling = sibling.querySelector("div *");
      let siblingIndex = asibling.getAttribute("data-index").valueOf();
      getsiblingIndex = +siblingIndex;
     // console.log(">>>>>>Sibling Index -->"+ siblingIndex +"<--<<<<<<");
      let siblingNode = this.filteredOpportunityDataArray.find(n => n.getAttribute("data-index").valueOf() === siblingIndex);
      index = siblingNode == null ? 0:this.filteredOpportunityDataArray.indexOf(siblingNode);
    }
    else
    {
      index = this.filteredOpportunityDataArray.length;
    }
    if(index > 15)
    {
      
      if(direction)
      {
        this.filteredOpportunityDataArray.splice(index,0,newAddElement);
        this.filteredOpportunityDataArray.splice(index + diffIndex + 1 , 1);
        //console.log("Length >>>>> "+this.filteredOpportunityDataArray.length);
      }
      else
      {
        this.filteredOpportunityDataArray.splice(index,0,newAddElement);
        this.filteredOpportunityDataArray.splice(index - (diffIndex + 1) , 1);
        let finalNewElement = this.insertCategoryAttributeService.resetOpportunityData(this.filteredOpportunityDataArray, index, this.categoryName);
        this.resetDataIndexAttr();
        this.pushIntoFilteredArray();
      }
      //newAddElement.removeAttribute("data-new");
    }
    else
    {
      if(direction)
      {
        
        
        if(this.filteredOpportunityDataArray.length<15)
        {
          this.filteredOpportunityDataArray.splice(index,0,newAddElement);
          if(this.filteredOpportunityDataArray.length>9)
          {
            this.filteredOpportunityDataArray.splice(diffIndex + index + 1,1);
          }
          else{
            this.filteredOpportunityDataArray.splice(index -1,1);
          }
        }
        else
        {
          if(this.filteredOpportunityDataArray.length>9 && index<15)
          {
            //this.filteredOpportunityDataArray.splice(index,0,newAddElement);
            //this.filteredOpportunityDataArray.splice(diffIndex + index + 1,1);
          }
          else
          {
            this.filteredOpportunityDataArray.splice(index,0,newAddElement);
            this.filteredOpportunityDataArray.splice(index -1,1);
          }
        }
      }
      else
      {
        debugger;
         if(diffIndex > index)
         {
          
            this.filteredOpportunityDataArray.splice(index,0,newAddElement);
            this.filteredOpportunityDataArray.splice(diffIndex + (index+1),1);
            this.pushIntoFilteredArray();
         }
        else
        {
          
            this.pushIntoFilteredArray();
        }
      }

    }
    
    //console.log(">>>>>>Sibling Index -->"+ index +"<--<<<<<<");
   }

  ResetOppertunityDataListNewAddElement(newAddElement: Element, sibling: Element): void {
   // debugger;
   try{
             
    this.RemoveEmptyElement();

              let addNodeIndex = this.filteredOpportunityDataArray.findIndex(line => line.getAttribute("data-new") == "true");
                  //console.log(">>>>>>--"+ addNodeIndex+"--<<<<<<");
                  this.filteredOpportunityDataArray.splice(addNodeIndex, 1);
                  let index: number;
                  let indexSibling:number;
                  let indexInArr = 0;
                  if(sibling != null)
                  {
                    let asibling = sibling.querySelector("div *");
                    //console.log(">>>>>>Sibling Index -->"+ asibling +"<--<<<<<<");
                    let siblingIndex =asibling.hasAttribute("data-index") ? asibling.getAttribute("data-index").valueOf():0;
                    //console.log(">>>>>>Sibling Index -->"+ siblingIndex +"<--<<<<<<");
                    let siblingNode = this.filteredOpportunityDataArray.find(n => n.getAttribute("data-index").valueOf() === siblingIndex);
                    index = siblingNode == null ? 0: this.filteredOpportunityDataArray.indexOf(siblingNode);
                    //index =  this.filteredOpportunityDataArray.length ===1 ? 0 : null;
                  }
                  else
                  {
                    index = this.filteredOpportunityDataArray.length;
                  }
                  if(index !=null)
                    {
                      //console.log("---->"+index+"<------");
                      let dataKey = newAddElement.getAttribute('data-key') == null ? "":newAddElement.getAttribute('data-key').valueOf();
                      newAddElement.innerHTML
                      //add new element
                      newAddElement.removeAttribute("data-new");
                      newAddElement.removeAttribute("data-key");
                      if(dataKey!="")
                      {
                          for(var i =0;i < this.RfpDataArray.length;i++)
                          {
                              
                                indexInArr = newAddElement.innerHTML===this.RfpDataArray[i].innerHTML ? i : 0
                                if(indexInArr > 0)
                                    break;
                          }
                          console.log("----"+this.RfpDataArray[i].getAttribute('data-key') +"----"+indexInArr);
                          indexSibling = index;
                          for(var kk = indexInArr;kk < this.RfpDataArray.length;kk++)
                          {
                            var getDataKey =  this.RfpDataArray[kk].getAttribute('data-key');
                            if(getDataKey !=null)
                            {
                            //console.log(">>>>>>>>>>>>>>> -- index --"+kk+""+this.RfpDataArray[kk]+"-->DK-->"+getDataKey+"<<<<<<<<<<<<<");
                            var parentKey = dataKey.split('/');
                            //console.log(">>>>>>>>>>>>>>>"+parentKey+'<<<<<<<<<<<<<<');
                            var childKey = getDataKey != null ? getDataKey.split('/'):[0];
                            var consParentKey = "";
                            var consChildKey = "";
                            console.log("---------"+childKey+"---------");
                            if(childKey.length >= parentKey.length)
                            {
                                  for(var l=0;l < parentKey.length;l++)
                                  {
                                    consParentKey += parentKey[l];
                                    consChildKey += childKey[l];
                                  }
                                  //console.log(">>>>>>>>>>>>>>>"+consParentKey+"---"+consChildKey+"--<<<<<<<<<<<<<");
                                  if(consParentKey===consChildKey)
                                  {
                                    if(indexSibling === index)
                                    {
                                      this.filteredOpportunityDataArray.splice(index, 0, this.RfpDataArray[kk]);
                                      indexSibling = indexSibling+1;
                                    }
                                    else
                                    {
                                      this.filteredOpportunityDataArray.splice(indexSibling, 0,  this.RfpDataArray[kk]);
                                      indexSibling = indexSibling+1;
                                    }
                                  //console.log(">>>>>>>>>>>>>>>--matched Child--> "+getDataKey+"--<<<<<<<<<<<<<");
                                  }else
                                  {break;}
                            }
                          }
                        }
                      }
                      else
                      {
                        if(sibling != null){
                          this.filteredOpportunityDataArray.splice(index, 0, newAddElement);
                        }
                        else
                        {
                          this.filteredOpportunityDataArray.push(newAddElement);
                        }
                      }

                      let finalNewElement = this.insertCategoryAttributeService.resetOpportunityData(this.filteredOpportunityDataArray, index, this.categoryName);
                      this.resetDataIndexAttr();
                      this.pushIntoFilteredArray();
                    
                }
      }
      catch(error){
        //console.log("---->"+this.filteredOpportunityDataArray.length+"<----");
        //console.log(">>>>>>>>>>>>>>>Error--> "+error+"--<<<<<<<<<<<<<");
      }
  }

  resetDataIndexAttr(): void {
    let datakey: string = "";
    for (let index = 0; index < this.filteredOpportunityDataArray.length; index++) {
      this.filteredOpportunityDataArray[index].setAttribute("data-index", index.toString());
      this.filteredOpportunityDataArray[index].setAttribute("data-cat", "");
      //............. setting data-key    start  
      if (!this.filteredOpportunityDataArray[index].hasAttribute("data-key")) { // if data-key attr is not present

        this.filteredOpportunityDataArray[index].setAttribute("data-key", index.toString());

        if (index - 1 !== -1) {
          datakey = this.filteredOpportunityDataArray[index - 1].getAttribute("data-key");
          this.filteredOpportunityDataArray[index].setAttribute("data-key", datakey);
          //console.log( datakey,this.filteredOpportunityDataArray[index-1].outerHTML);
        }
        else {
          if(this.filteredOpportunityDataArray[index + 1] != undefined){
            datakey = this.filteredOpportunityDataArray[index + 1].getAttribute("data-key");
            this.filteredOpportunityDataArray[index].setAttribute("data-key", datakey);
          }
        }
      }
      //.............  setting data-key    end 
    }
  }

  LoadRfpData(rfpDoc: string, flag: string): void {
    if (rfpDoc != null) {
      let doc = new DOMParser().parseFromString(rfpDoc, "text/html");
      let div = doc.querySelector("div");
      switch (flag) {
        case 'fromFileUpload':
          this.loadLeftPaneData(div.children);
          //this.loadOppertunityData(doc);
          break;
        case "fromDbExistingFile":
          this.loadLeftPaneData(div.children);
          break
      }
    }
    else {
      this.RfpDataArray.length = 0;
      this.RfpDataArray = [];
      this.filteredOpportunityDataArray.length = 0;
      this.filteredOpportunityDataArray = [];
      this.isSummary = false;

    }
  }

  loadLeftPaneData(htmlCollection: HTMLCollection): void {

    [].forEach.call(htmlCollection, (item: HTMLElement, index: number) => {
      item.setAttribute("data-draggable", "true");
      item.style.cursor = "move";
      this.RfpDataArray.push(item);
    });
    this.RfpDataArray = Array.from(this.RfpDataArray);
  }


  RestDataIndexAttribute(stringHtml: any, categoryId: string): Array<Element> {
    let dataCategoryList = [];
    let dataCategoryListElements: Array<Element> = [];
    let doc = new DOMParser().parseFromString(stringHtml, "text/html");
    dataCategoryList = Array.from(doc.querySelectorAll("[data-cat]"));

    [].forEach.call(dataCategoryList, (item: HTMLElement, index: number) => {
      item.setAttribute("data-index", index.toString());
      dataCategoryListElements.push(item);

    });
    return dataCategoryListElements;
  }

  RouteParam(): void {

    this.route.queryParamMap.subscribe(params => {

      this.categoryName = params.get('category');

      if (this.categoryName == 'summary') {
        this.filteredOpportunityDataArray = [];
        this.isSummary = true;
      }
      else if (this.categoryName === null && (typeof this.categoryArray !== "undefined")) {

        this.categoryName = 'summary';
        this.isSummary = true;
      }
      else {
        this.isSummary = false;

        this.filteredOppoertunity();
        if (this.filteredOpportunityDataArray.length > 0) {

          this.validateChange.initData(this.filteredOpportunityDataArray);
        }
      }
    });
  }


  filteredOppoertunity(): void {
    let categoryId = this.categoryName;;
    var obj: OppertunityCategory = this.oppertunityCategoryArray.find(element => {
      return element.categoryId == categoryId;
    });
    this.filteredOpportunityDataArray = obj != undefined ? obj.categoryData : [];
  }


  OpenEditor(event: any) {
    event[0].stopPropagation(event[0]);
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.width = '700px';
    
    dialogConfig.data = {
      id: 1,
      title: 'Editor',
      opportunityData: this.filteredOpportunityDataArray
    };

    const dialogRef = this.dialog.open(TinymceComponent, dialogConfig);
    dialogRef.afterClosed().subscribe(
      data => {
        if (data !== undefined){
          
          this.ResetDataFromEditor(data);
          
        }

      });
  }

  popUpGridOpenOpp() {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.width = '70%';

    dialogConfig.data = {
      headerFlag: true,
      opportunityComponent: this,
      publish: false
    };

    const dialogRef = this.dialog.open(DocumentListComponent, dialogConfig);
    dialogRef.afterClosed().subscribe(
      
       data => {
         if (data !== undefined){
        this.ResetDataFromEditor(data);
         }
       }
    );
  }

  ResetDataFromEditor(tinyData: string): void {
    if (tinyData == "") {
     
     tinyData =  this.GetEmptyElement().outerHTML;

    

    }
    let categoryData: Element[] = [];
    var doc = new DOMParser().parseFromString(tinyData, "text/html");
    let doc1 = doc.documentElement.innerHTML;
    let dataCategoryList = doc.querySelector("body");
    [].forEach.call(dataCategoryList.children, (item: HTMLElement, index: number) => {
      item.setAttribute("data-category", this.categoryName);
      categoryData.push(item);
    });

    
    this.filteredOpportunityDataArray = [];
    this.filteredOpportunityDataArray = categoryData;
    this.pushIntoFilteredArray();
  }

  DeleteOpportunityText(deletedInfo: any) {
    if (this.filteredOpportunityDataArray.length === 1) {
     
      let deletedNode: Element = this.filteredOpportunityDataArray[deletedInfo[1]]

      if(deletedNode.hasAttribute("data-temptrow")){
        return;
      } 
      else{
        
        
      this.filteredOpportunityDataArray = [];
      this.filteredOpportunityDataArray[0] = this.GetEmptyElement();
      this.resetDataIndexAttr();
      this.pushIntoFilteredArray();

      }

    }
    else if(this.filteredOpportunityDataArray.length > 1)
    {

      if (deletedInfo.length > 1) {
        let opportunityData = deletedInfo[0];
        let deteletedTextIndex1 = deletedInfo[1];
        this.filteredOpportunityDataArray = this.filteredOpportunityDataArray.filter((a, index) => index !== deteletedTextIndex1);
         /// ....
        this.pushIntoFilteredArray();
         ///....
       }
    }
  }

  pushIntoFilteredArray(): void {
    
    let categoryId: string;
    this.route.queryParamMap.subscribe(params => {
      if (params.has('category')) {
        
        categoryId = params.get('category');
      }
    });

    let catIndex = this.oppertunityCategoryArray.findIndex(item => item.categoryId == categoryId);

    if (catIndex == -1) return;

     if (this.oppertunityCategoryArray[catIndex].categoryData.length > 0) {
      this.oppertunityCategoryArray[catIndex].categoryData.length = 0;
       this.oppertunityCategoryArray[catIndex].categoryData = [];
    }
    
    this.oppertunityCategoryArray[catIndex].categoryData = this.filteredOpportunityDataArray;
    
  }

  navigateToDefaultPath() {
    this.router.navigate(['/opportunity']);
  }

  getSavedDocInfo(companyId: any, userId: any, documentId: any) {

  
    this.isLoading = true;
    this.dialog.closeAll();

    this.ClearForm();

    this.documentParserFormService.getSavedDocInfo(companyId, userId, documentId).subscribe(
      (response) => {

        this.documentName = response.documentName;
        this.LoadRfpData(response.document, "fromDbExistingFile")
        let self = this;
        if (self.categoryArray != null && self.categoryArray.length > 0) { self.categoryArray.length = 0; }
        if (response.categoryData) {

          response.categoryData.forEach(function (element) {
            let categoryObj = {
              CategoryId: element.CategoryId,
              Name: element.Name
            }
            self.categoryArray.push(categoryObj);
          });
          this.fillOppeCatArray(this.categoryArray, response.categoryData);
        }

        localStorage.setItem('documentId', response.documentId);
        this.documentSummaryComponent.createGroup(response.summary);

        if (response.status !== 'error' && this.categoryArray.length !== null && this.categoryArray.length != 0) {
          this.RouteParam();
          this.documentUploadComponent.isBtnPubDisabled = false;
          this.notification.success("Record retrived from cloud.");
        }
        else {
          if (response.documentId == 0 || response.documentId == '0') {
            this.notification.warning("No pending document found. ");
          }
          else {
            this.notification.error(response.message);
          }
        }
        this.isLoading = false;
      },
      (error: any) => {
        this.isLoading = false;
        //console.log(error);
        this.notification.error(error);
      }
    )
  };


  ngOnDestroy() {
    const bag: any = this.dragulaService.find('Copy');
    if (bag !== undefined) this.dragulaService.destroy('Copy');
    this.subs.unsubscribe();
  }

  ClearForm() {
    this.isSummary = false;
    this.RfpDataArray = [];
    this.filteredOpportunityDataArray = [];
  }

  
  CreateElementForEmptyCategory(categoryId: string): Array<Element> {
  let divString: string = this.GetEmptyElement().outerHTML;

  return this.RestDataIndexAttribute(divString, categoryId);

  }

  NotDeletedRow(element: Element): boolean {
    //debugger;
    let attribute = element.getAttribute("data-lastrow");
    if (attribute == undefined && attribute == null) {
      return false;
    }
    return true;
  }

  GetEmptyElementString(): string{
    //debugger;
    let categoryId: string;

    this.route.queryParamMap.subscribe(params => {
      if (params.has('category')) {
        
        categoryId = params.get('category');
      }
    });
    let divString: string =  "<div data-temptrow=true data-category=" + categoryId + " data-cat='' data-key='1'><< Double click / drop text here >></div>"

    return divString;
  }

  GetEmptyElement(): Element{
    //debugger;
    let categoryId: string;

    this.route.queryParamMap.subscribe(params => {
      if (params.has('category')) {
        
        categoryId = params.get('category');
      }
    });

   
   let bElement: Element = document.createElement("b");
   let content:Text = document.createTextNode("<< Double click / drop text here >>");

   bElement.appendChild(content)

   let divElement: Element = document.createElement("div");
   
    divElement.appendChild(bElement);
    divElement.setAttribute("data-temptrow","true");
    divElement.setAttribute("data-category",categoryId);
    divElement.setAttribute("data-cat","");
    divElement.setAttribute("data-key","1");
    
    return divElement;
  }

  RemoveEmptyElement(){
    //debugger;
    if(this.filteredOpportunityDataArray.length > 0 ){

     let elementIndex: number =  this.filteredOpportunityDataArray.findIndex(el => el.getAttribute('data-temptrow') === 'true');
      console.log("---->element index--"+elementIndex+"---<----");
     if(elementIndex >= 0){
           this.filteredOpportunityDataArray.splice(elementIndex,1)
     }
 
    }
  }
}
import { Component, OnInit,Inject} from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MAT_DIALOG_DATA,MatDialogRef } from '@angular/material/dialog';
import { DocumentSummaryComponent } from '../document-summary/document-summary.component';//'../opportunity/summary/summary.component';
import { SummaryField } from '../../Shared/models/SummaryField';
import { ControlType } from '../../Shared/Models/ControlType';


@Component({
  selector: 'app-addfield-dialog',
  templateUrl: './addfield-dialog.component.html',
  styleUrls: ['./addfield-dialog.component.css']
})
export class AddfieldDialogComponent implements OnInit {
  id:number=0;
  fieldType:string;
  fieldtypes:any = ['TextBox','DateTime'];
  fieldLabel:string='';
  groupForm:FormGroup;
  required:Boolean=false;
  summary:DocumentSummaryComponent;
  //summarArray: Array<SummaryField>;
  summaryField: SummaryField;

  selectedTypeCode: string;
  controlTypes: ControlType[] = [
    {typeCode: 1 , typeValue: 'TextBox'},
    {typeCode: 3 , typeValue: 'DateTime'}
  ]
  constructor(private fb: FormBuilder,
    public dialogRef: MatDialogRef<AddfieldDialogComponent>,
    @Inject(MAT_DIALOG_DATA) data) {
      console.log('--->'+ data.id + '<---');
      this.id = data.id;
      this.summary = data.summary;
    }
    ngOnInit() {
      this.groupForm = this.fb.group({
        labelfield: ['', [Validators.required,Validators.maxLength(15)]],
        typefield: ['', [Validators.required]]
      });
  }
  Cancel(){
    this.dialogRef.close();
  }

  ChangeFieldType(e) {
   let strValue = e.target.value;
   let arr = strValue.indexOf(':') === 1 ? strValue.split(': ') : [0];
   this.fieldType = arr[0] === 0 ? strValue : arr[1].toString()
  }
  Done(){
    if (this.groupForm.valid)
    {
        console.log('---> '+this.fieldLabel+' <---');
        console.log('---> '+ this.fieldType+ ' <---');
        //this.summary.addField(this,this.id,this.fieldLabel,this.fieldType);
        //this.dialogRef.close();
        //this.summarArray = new Array<SummaryField>();
        this.summaryField = new SummaryField(this.fieldLabel,this.fieldType,"",0,0);

        this.dialogRef.close(this.summaryField );
    }else
    {
      this.required=true;
    }
  }
 }
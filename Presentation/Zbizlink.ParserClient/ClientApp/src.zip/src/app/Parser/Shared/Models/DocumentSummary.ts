export class DocumentSummary {
    summaryId: number;
    proposalName: string;
    solicitationNumber: string;
    startDate: string;
    dueDateTime: string;
    preBidDate: string;
    qaDate: string;
    agency:string;
    }
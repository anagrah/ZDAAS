export interface ControlType {
    typeCode: number;
  typeValue: string;
  }

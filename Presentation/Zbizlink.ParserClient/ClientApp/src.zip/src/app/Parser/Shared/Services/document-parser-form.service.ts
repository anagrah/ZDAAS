import { Injectable } from '@angular/core';
import { Observable, throwError } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { HttpClient, HttpEvent, HttpErrorResponse, HttpEventType, HttpHeaders, HttpParams } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { AppConfigService } from 'src/app/Shared/services/app-config.service';

@Injectable({
  providedIn: 'root'
})
export class DocumentParserFormService {
  //apiUrl = environment.baseUrl;

  //sharepointapiUrl = environment.sharepointbaseUrl;
  
  //apiUrl ="http://localhost:63976/api/";
  // apiUrl ="https://rfpapi.zbizlink.com/api/";

  apiUrl = this.appConfigService.apiBaseUrl;
  sharepointapiUrl = this.appConfigService.sharepointapiUrl;

  constructor(private http: HttpClient, private appConfigService: AppConfigService) { }

  getRFPFromWebApi(): Observable<any> {
    return this.http.get<any>(this.apiUrl);
  }


  upload(formData: any): Observable<any> {
    console.log(this.apiUrl);
    return this.http.post<any>(`${this.apiUrl + "document/Upload"}`, formData, {
      observe: 'events'
    }).pipe(
      map(event => this.getEventMessage(event, formData)),
      catchError(this.handleError)
    );
  }

  uploadSharePoint(formData:any): Observable<any>
  {
    console.log('>>>>>share point url<<<<<');
    console.log('>>>>>'+this.sharepointapiUrl+'<<<<<');
    return this.http.post<any>(`${this.sharepointapiUrl + "api/Document/Upload"}`,formData)
    .pipe(catchError(this.handleError));
  }

  save(formData: any): Observable<any> {
    return this.http.post<any>(`${this.apiUrl + "document/Save"}`, formData)
      .pipe(catchError(this.handleError));
  }

  private getEventMessage(event: HttpEvent<any>, formData) {

    switch (event.type) {
      case HttpEventType.UploadProgress:
        return this.fileUploadProgress(event);
      case HttpEventType.Response:
        return this.apiResponse(event);
      default:
        return `File "${formData.get('file').name}" surprising upload event: ${event.type}.`;
    }
  }

  private fileUploadProgress(event) {
    const percentDone = Math.round(100 * event.loaded / event.total);
    return { status: 'progress', message: percentDone };
  }

  private apiResponse(event) {
    //console.log(event.body);
    return event.body;
  }

  getPublicOppertunityList(publishFlag: boolean): Observable<any> {
debugger;
    var companyId=localStorage.getItem('compId');

    if (publishFlag == false) {
      return this.http.get(`${this.apiUrl}document/GetNonePublishedDocumentList?companyId=${companyId}`)
        .pipe(catchError(this.handleError));
    }
    else {
      return this.http.get(`${this.apiUrl}document/GetPublishedDocumentList?companyId=${companyId}`)
        .pipe(catchError(this.handleError));

    }
  }

  // Waqar 
  getOpportunity(): Observable<any> {
    return this.http.get(`${this.apiUrl}Opportunity/getopportunity`)
      .pipe(catchError(this.handleError));
  }

  getSavedDocInfo(companyId: any, userId: any, documentId: any): Observable<any> {
    let Params = new HttpParams();
    Params.append('companyId', companyId);
    Params.append('userId', userId);
    Params.append('documentId', documentId);
    // the above paramameter are not in use for instance .
    return this.http.post(`${this.apiUrl}document/GetSavedDocInfo?companyId=${companyId}&userId=${userId}&documentId=${documentId}`, null).pipe(catchError(this.handleError));
  }



  publish(documentId: any): Observable<any> {
    let docId: Number = Number(documentId);
    return this.http.post(`${this.apiUrl}Opportunity/publish?documentId=${docId}`, null)
    .pipe(catchError(this.handleError));
  }

  private handleError(error: HttpErrorResponse) {
//debugger;
    if (error.error instanceof ErrorEvent) {
      // A client-side or network error occurred. Handle it accordingly.
      console.error('An error occurred:', error.error.message);
    } else {
      // The backend returned an unsuccessful response code.
      // The response body may contain clues as to what went wrong,
      console.error(`Backend returned code ${error.status}, ` + `body was: ${error.error}`);
    }
    // return an observable with a user-facing error message
     
    //return throwError(error); 
    return throwError('Something bad happened. Please try again later.');
  }
}
import { Component } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  
  constructor(private route: ActivatedRoute) {}
  //constructor(){}

  ngOnInit()
  {
    this.route.queryParams.forEach(params => 
      {
        debugger;
        //var clientIDTest = localStorage.getItem('clientID').toString();
        //var clientID = parseInt(localStorage.getItem('clientID').length.toString());
        //var companySegmentID = parseInt(localStorage.getItem('companySegmentID').length.toString());
        //var userid = parseInt(localStorage.getItem('userid').length.toString());
        //var compId  = parseInt(localStorage.getItem('compId').length.toString());
        if(typeof params.compid != 'undefined')
        {
          typeof params.compid === 'undefined' ? localStorage.setItem('compId', '0') : localStorage.setItem('compId', params.compid);
          typeof params.userid === 'undefined' ? localStorage.setItem('userid', '0') : localStorage.setItem('userid', params.userid);
          typeof params.companySegmentID === 'undefined' ? localStorage.setItem('companySegmentID', '0') : localStorage.setItem('companySegmentID', params.companySegmentID);
          typeof params.clientID === 'undefined' ? localStorage.setItem('clientID', '0') : localStorage.setItem('clientID', params.clientID);
        }
      });
  }
}
